output = system.exec_command("date '+%H:%M'")
keyboard.send_keys(output)